public enum MatchType {
	EXACT, PREFIX
}
